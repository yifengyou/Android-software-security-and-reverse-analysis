package com.droider.stackTrace;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        setTitle("stackTrace��ʾʵ��");        
        a();        
    }
    
    private void a() {
    	b();
    }
    
    private void b() {
    	c();
    }
    
    private void c() {
    	Toast.makeText(MainActivity.this, "who called me?", Toast.LENGTH_SHORT).show();
    	//new Exception("print trace").printStackTrace();		
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
}

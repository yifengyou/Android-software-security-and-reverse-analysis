/** Automatically generated file. DO NOT MODIFY */
package com.droider.stackTrace;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
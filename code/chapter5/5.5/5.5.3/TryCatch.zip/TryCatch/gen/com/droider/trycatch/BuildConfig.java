/** Automatically generated file. DO NOT MODIFY */
package com.droider.trycatch;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
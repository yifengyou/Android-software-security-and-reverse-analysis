package com.droider.trycatch;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tryCatch(100, "6");
    }
    
    private void tryCatch(int drumsticks, String peple) {
        try {
            int i = Integer.parseInt(peple);
            try {
                int m = drumsticks / i;
                int n = drumsticks - m * i;
                String str = String.format("����%dֻ���ȣ�%d����ƽ�֣�ÿ�˿ɷֵ�%dֻ����ʣ��%dֻ",
                        drumsticks, i, m, n);
                Toast.makeText(MainActivity.this, str, Toast.LENGTH_SHORT).show();
            } catch (ArithmeticException e) {
                Toast.makeText(MainActivity.this, "��������Ϊ0", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "��Ч����ֵ�ַ���", Toast.LENGTH_SHORT).show();
        }
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    
}

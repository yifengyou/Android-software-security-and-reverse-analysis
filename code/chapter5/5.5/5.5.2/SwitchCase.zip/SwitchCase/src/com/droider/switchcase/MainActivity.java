package com.droider.switchcase;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String str1 = packedSwitch(1);
        Toast.makeText(MainActivity.this, str1, Toast.LENGTH_SHORT).show();
        String str2 = sparseSwitch(35);
        Toast.makeText(MainActivity.this, str2, Toast.LENGTH_SHORT).show();
    }
    
    private String packedSwitch(int i) {
        String str = null;
        switch (i) {
            case 0:
                str = "she is a baby";
                break;
            case 1:
                str = "she is a girl";
                break;
            case 2:
                str = "she is a woman";
                break;
            case 3:
                str = "she is an obasan";
                break;
            default:
                str = "she is a person";
                break;
        }
        return str;
    }
    
    private String sparseSwitch(int age) {
        String str = null;
        switch (age) {
            case 5:
                str = "he is a baby";
                break;
            case 15:
                str = "he is a student";
                break;
            case 35:
                str = "he is a father";
                break;
            case 65:
                str = "he is a grandpa";
                break;
            default:
                str = "he is a person";
                break;
        }
        return str;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    
}

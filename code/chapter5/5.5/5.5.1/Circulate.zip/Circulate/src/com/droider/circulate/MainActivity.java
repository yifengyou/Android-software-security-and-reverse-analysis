package com.droider.circulate;

import android.os.Bundle;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.view.Menu;
import android.widget.Toast;

import java.util.Iterator;
import java.util.List;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        iterator();     //������ѭ��
        forCirculate(); //forѭ��
        whileCirculate();  //whileѭ��
        dowhileCirculate(); //do whileѭ��
    }

    /**
     * ��ȡ�������еĽ����б�
     */
    private void iterator() {
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<RunningAppProcessInfo> psInfos = activityManager.getRunningAppProcesses();
        StringBuilder sb = new StringBuilder();
        for (RunningAppProcessInfo info : psInfos) {
            sb.append(info.processName + '\n');
        }
        Toast.makeText(MainActivity.this, sb.toString(), Toast.LENGTH_SHORT).show();
    }

    /**
     * ��ȡ�Ѱ�װ�ĳ���
     */
    private void forCirculate() {
        PackageManager pm = getApplicationContext().getPackageManager();
        List<ApplicationInfo> appInfos = pm.getInstalledApplications(
                PackageManager.GET_UNINSTALLED_PACKAGES);
        int size = appInfos.size();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            ApplicationInfo info = appInfos.get(i);
            sb.append(info.packageName + '\n');
        }
        Toast.makeText(MainActivity.this, sb.toString(), Toast.LENGTH_SHORT).show();
    }
    
    /**
     * ��ȡ�������е������б�
     */
    private void whileCirculate() {
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<RunningTaskInfo> taskInfos = activityManager.getRunningTasks(100);
        StringBuilder sb = new StringBuilder();
        Iterator<RunningTaskInfo> iterator = taskInfos.iterator();
        while (iterator.hasNext()) {
            RunningTaskInfo info = iterator.next();
            sb.append(info.toString() + '\n');
        }
        Toast.makeText(MainActivity.this, sb.toString(), Toast.LENGTH_SHORT).show();
    }
    
    /**
     * ��ȡ���ڶ�Ǩ�ķ����б�
     */
    private void dowhileCirculate() {
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<RunningServiceInfo> serviceInfos = activityManager.getRunningServices(100);
        StringBuilder sb = new StringBuilder();
        Iterator<RunningServiceInfo> iterator = serviceInfos.iterator();
        do {
            RunningServiceInfo info = iterator.next();
            sb.append(info.toString() + '\n');
        } while (iterator.hasNext());
        Toast.makeText(MainActivity.this, sb.toString(), Toast.LENGTH_SHORT).show();
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    
}


// DexFixerDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DexFixer.h"
#include "DexFixerDlg.h"
#include "DexHelper.h"
#include <process.h>

using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnNMClickSyslinkme(NMHDR *pNMHDR, LRESULT *pResult);
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	ON_NOTIFY(NM_CLICK, IDC_SYSLINKME, &CAboutDlg::OnNMClickSyslinkme)
END_MESSAGE_MAP()

CDexFixerDlg::CDexFixerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDexFixerDlg::IDD, pParent)
	, m_bPatching(false)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	RtlZeroMemory(m_fileName, MAX_PATH);
}

void CDexFixerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, LST_OUTPUT, m_lstInfo);
}

BEGIN_MESSAGE_MAP(CDexFixerDlg, CDialog)
	//{{AFX_MSG_MAP(CDexFixerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DROPFILES()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_OPEN, &CDexFixerDlg::OnBnClickedOpen)
	ON_BN_CLICKED(IDC_ABOUT, &CDexFixerDlg::OnBnClickedAbout)
END_MESSAGE_MAP()

BOOL CDexFixerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	m_lstInfo.AddString("�Ϸ�Ҫ�޸���DEX�ļ����˴�");

	return TRUE;  
}

void CDexFixerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CDexFixerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); //

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CDexFixerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CDexFixerDlg::OnBnClickedOpen()
{
	CFileDialog dlg(TRUE, "dex", NULL, OFN_HIDEREADONLY |OFN_FILEMUSTEXIST | OFN_FORCESHOWHIDDEN, 
					"Dex Files(*.dex)|*.dex|All Files(*.*)|*.*||");
	char buff[MAX_PATH] = {0};
	dlg.m_ofn.lpstrFile = buff;
	dlg.m_ofn.nMaxFile = MAX_PATH;
	if (dlg.DoModal() == IDOK && !m_bPatching)
	{
		unsigned int dwThreadID = 0;
		HANDLE h = (HANDLE)_beginthreadex(NULL, 0, 
			ThreadProc, (LPVOID)this, 0, NULL);
	}
}

unsigned __stdcall CDexFixerDlg::ThreadProc( LPVOID lpParam )
{
	CDexFixerDlg * pWnd = (CDexFixerDlg *)lpParam;
	pWnd->m_bPatching = true;
	try
	{
		CDexHelper dex(pWnd->m_fileName);
		pWnd->m_lstInfo.AddString("������֤DEX�ļ�...");
		if (!dex.CheckSignature())
		{
			pWnd->m_lstInfo.AddString("DEX�ļ���־��֤ʧ��");
			dex.Close();
			return 0;
		}
		pWnd->m_lstInfo.AddString("DEX�ļ���־��֤ͨ��");
		if (dex.CheckSHA1())
		{
			pWnd->m_lstInfo.AddString("DEX�ļ�SHA1��֤ͨ��");
		}
		else
		{
			pWnd->m_lstInfo.AddString("DEX�ļ�SHA1��֤ʧ��");
			dex.ResetSHA1();
			pWnd->m_lstInfo.AddString("DEX�ļ�SHA1ֵ������");
			pWnd->m_lstInfo.AddString(dex.GetSha1String());
		}
		if (dex.Checkadler32())
		{
			pWnd->m_lstInfo.AddString("DEX�ļ�checksum��֤ͨ��");
		}
		else
		{
			pWnd->m_lstInfo.AddString("DEX�ļ�checksum��֤ʧ��");
			dex.ResetAdler32();
			pWnd->m_lstInfo.AddString("DEX�ļ�checksumֵ������");
			pWnd->m_lstInfo.AddString(dex.GetAdler32String());
		}
		dex.Close();
		pWnd->m_lstInfo.AddString("���в��������");
	}
	catch (CException* e)
	{
		pWnd->m_lstInfo.AddString("�Ƿ���DEX�ļ�");
	}
	
	pWnd->m_bPatching = false;
	return 1;
}

void CDexFixerDlg::PreSubclassWindow() 
{
	DragAcceptFiles(TRUE);
	CDialog::PreSubclassWindow();
}

void CDexFixerDlg::OnDropFiles( HDROP hDropInfo )
{
	RtlZeroMemory(m_fileName, MAX_PATH);
	::DragQueryFile( hDropInfo, 0, m_fileName, MAX_PATH );
	if(!m_bPatching)
	{
		unsigned int dwThreadID = 0;
		HANDLE h = (HANDLE)_beginthreadex(NULL, 0, 
			ThreadProc, (LPVOID)this, 0, NULL);
	}
}

void CDexFixerDlg::OnBnClickedAbout()
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}


void CAboutDlg::OnNMClickSyslinkme(NMHDR *pNMHDR, LRESULT *pResult)
{
	PNMLINK pNMLink = (PNMLINK)pNMHDR;
	//wstring wstr = pNMLink->item.szUrl; 
	::ShellExecuteA(m_hWnd, "open", "mailto:fei_cong@hotmail.com", NULL, NULL, SW_SHOWNORMAL);
	*pResult = 0;
}

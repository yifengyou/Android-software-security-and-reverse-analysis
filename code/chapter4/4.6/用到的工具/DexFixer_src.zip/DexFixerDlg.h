
// DexFixerDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "stdint.h"

typedef enum tagDexType{
	DEXF_NULL,
	DEXF_DEX,
	DEXF_ODEX
} DexType;

class CDexFixerDlg : public CDialog
{
public:
	CDexFixerDlg(CWnd* pParent = NULL);	// ��׼���캯��

	enum { IDD = IDD_DEXFIXER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	virtual BOOL OnInitDialog();
	virtual void PreSubclassWindow();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOpen();
	static unsigned __stdcall ThreadProc( LPVOID lpParam );
	CListBox m_lstInfo;
	char m_fileName[MAX_PATH];
	bool m_bPatching;
	afx_msg void OnBnClickedAbout();
};

#include "StdAfx.h"
#include "DexHelper.h"
#include "adler32.h"
#include "sha1.h"

const unsigned char dexmagic[8] = {0x64, 0x65, 0x78, 0x0A, 0x30, 0x33, 0x35, 0};//"dex\n35\0";	 

CDexHelper::CDexHelper( const char* szFileName )
{
	CFileStatus status;
	CFile::GetStatus(szFileName, status);
	status.m_attribute &= ~CFile::readOnly;	//ȥ��ֻ������
	CFile::SetStatus(szFileName, status);
	m_DexFile.Open(szFileName, CFile::modeReadWrite);
	if (m_DexFile.GetLength() < sizeof(m_Header)) return;
	m_DexFile.Read(&m_Header, sizeof(m_Header)); //��ȡDexHeaderͷ

	GetRealSHA1();
	GetRealAdler32();
}

CDexHelper::~CDexHelper(void)
{
}

bool CDexHelper::CheckSignature()
{
	if (memcmp(m_Header.magic, dexmagic, 8) == 0) return true;
	else return false;
}

void CDexHelper::GetRealSHA1()
{
	SHA1Context sha;
	UINT len = sizeof(m_Header.magic) + sizeof(m_Header.checksum) + sizeof(m_Header.signature);
	unsigned char *ReadBuff  = new unsigned char[unsigned int(m_DexFile.GetLength() - len)];
	m_DexFile.Seek(len, CFile::begin);	//����magic + checksum + sha1
	m_DexFile.Read(ReadBuff, UINT(m_Header.fileSize-len)); //��ȡ�����ļ�
	SHA1Reset(&sha);
	SHA1Input(&sha, (const unsigned char *)ReadBuff, UINT(m_Header.fileSize - len));
	SHA1Result(&sha, m_Sha1Buffer); //����SHA1
	delete [] ReadBuff;
}

bool CDexHelper::CheckSHA1()
{
	if(memcmp(m_Header.signature, m_Sha1Buffer, 20) == 0) return true;
	else return false;
}

void CDexHelper::GetRealAdler32()
{
	UINT len = sizeof(m_Header.magic) + sizeof(m_Header.checksum);
	unsigned char *ReadBuff  = new unsigned char[unsigned int(m_DexFile.GetLength() - len)];
	m_DexFile.Seek(len, CFile::begin); //����magic + adler32
	m_DexFile.Read(ReadBuff, m_Header.fileSize - len);  //���¶�ȡ�ļ�
	m_Adler32 = adler32(ReadBuff, m_Header.fileSize - len);
	delete [] ReadBuff;
}

bool CDexHelper::Checkadler32()
{
	return (m_Header.checksum == m_Adler32);
}

void CDexHelper::ResetSHA1()
{
	GetRealSHA1();
	UINT offset = sizeof(m_Header.magic) + sizeof(m_Header.checksum);
	WriteBytes(offset, m_Sha1Buffer, sizeof(m_Header.signature));
}

void CDexHelper::ResetAdler32()
{
	GetRealAdler32();
	if (m_Adler32 == m_Header.checksum) return;
	UINT offset = sizeof(m_Header.magic);
	WriteBytes(offset, (void*)&m_Adler32, sizeof(m_Header.checksum));
}

CString CDexHelper::GetSha1String()
{
	CString str = "";
	CString strtmp = "";
	for(int i = 0; i < sizeof(m_Sha1Buffer) ; ++i)
	{
		strtmp.Format("%02X ", m_Sha1Buffer[i]);
		str += strtmp;
	}
	return str;
}

CString CDexHelper::GetAdler32String()
{
	char Adler32Buff[16] = {0};
	ultoa(m_Adler32, Adler32Buff, 16);
	CString str;
	str.Format("Adler32: %s", Adler32Buff);
	return str;
}


bool CDexHelper::CheckBytes( int DexOffset, const unsigned char* srcBuffer, int len )
{
	m_DexFile.Seek(DexOffset, CFile::begin);
	unsigned char* ReadBuff = new unsigned char[len];
	m_DexFile.Read(ReadBuff, len);
	bool result = true;	
	if (memcmp(ReadBuff, srcBuffer, len) != 0) result = false;
	delete [] ReadBuff;
	return result;
}

void CDexHelper::WriteBytes( int DexOffset, const void* Buffer, int len )
{
	m_DexFile.Seek(DexOffset, CFile::begin);
	m_DexFile.Write(Buffer, len);
	m_DexFile.Flush();
}

void CDexHelper::ReadBytes( int DexOffset, void* outBuffer, int len )
{
	m_DexFile.Seek(DexOffset, CFile::begin);
	m_DexFile.Read(outBuffer, len);
}

void CDexHelper::Close()
{
	m_DexFile.Close();
}

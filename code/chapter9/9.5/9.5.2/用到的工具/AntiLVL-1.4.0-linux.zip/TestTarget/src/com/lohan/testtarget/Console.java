package com.lohan.testtarget;

import android.util.Log;

public class Console {
	public static void log(String msg) {
		Log.d("lohan", msg);
	}
}

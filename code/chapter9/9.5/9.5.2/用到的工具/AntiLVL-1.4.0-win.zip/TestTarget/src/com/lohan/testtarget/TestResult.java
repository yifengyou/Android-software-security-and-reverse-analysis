package com.lohan.testtarget;

public enum TestResult {
	PASSED, FAILED, ERROR, NOKEY
}
